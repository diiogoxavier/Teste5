import { StrictMode, useState, useMemo, useCallback } from 'react'
import { createRoot } from 'react-dom/client'
import {
  BarChart, Bar, LineChart, Line,
  XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts'
/* ─── Estilos globais ─────────────────────────────────────────────────── */
const G = `
@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Montserrat',sans-serif;background:#0b0d14;color:#e2e4f0}
::-webkit-scrollbar{width:5px}
::-webkit-scrollbar-track{background:#13151f}
::-webkit-scrollbar-thumb{background:#3b4fd8;border-radius:3px}
@media print{
  .no-print{display:none!important}
  body{background:#fff!important;color:#000!important}
  .print-area{background:#fff!important;color:#000!important;padding:0!important}
}`;

/* ─── Helpers ─────────────────────────────────────────────────────────── */
const HOJE   = new Date();
const MES_N  = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
const MES_S  = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"];
const addM   = (d,n) => { const r=new Date(d); r.setMonth(r.getMonth()+n); return r; };
const toStr  = d => d instanceof Date ? d.toISOString().slice(0,10) : d;
const dataBR = s => s ? s.split("-").reverse().join("/") : "";
const ptBR   = v => Number(v).toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
const dias   = s => Math.ceil((new Date(s)-HOJE)/86400000);
const mesAtual = () => toStr(HOJE).slice(0,7);

/* ─── Dados dos contratos ─────────────────────────────────────────────── */
const IMOVEIS = {
  11419:{end:"Av. Carlos Lins Cortês, 515, Infraero, Macapá",        tipo:"Comercial"},
  2783: {end:"Rodovia BR-210, 0, Lagoa Azul, Macapá",                tipo:"Comercial"},
  2063: {end:"Av. Cora de Carvalho, 2502, Santa Rita, Macapá",       tipo:"Comercial"},
  11417:{end:"Rodovia BR 156, 4, Q2, Lagoa Azul, Macapá",            tipo:"Comercial"},
  1812: {end:"Rua Pedro Salvador Diniz, 372, Santana",               tipo:"Residencial"},
  318:  {end:"Rua Santos Dumont, 4340, Muca, Macapá",                tipo:"Comercial"},
  11301:{end:"Av. FAB, 449, Central, Macapá",                        tipo:"Comercial"},
  11041:{end:"Av. Almirante Barroso, 2587, Central, Macapá",         tipo:"Comercial"},
  1694: {end:"Av. Padre Júlio Lombaerd, 958, Central, Macapá",       tipo:"Residencial"},
  1373: {end:"Av. Dom Pedro I, 1115, Hospitalidade, Santana",        tipo:"Comercial"},
  1231: {end:"Rua Liberdade, 396, Renascer I, Macapá",               tipo:"Residencial"},
};

const CONTRATOS_BASE = [
  // EJDD
  {id:"20914/0450",im:11419,grupo:"EJDD",loc:"IDAILTON GOMES FERREIRA",       cpf:"499.535.672-04",     ini:"2026-03-25",fim:"2028-09-24",val:2800.00, dia:25,idx:"IGP-M",com:10,per:40,rej:"2026-03-25"},
  {id:"16993",     im:2783, grupo:"EJDD",loc:"RZK EQUIPAMENTOS LTDA",         cpf:"62.306.480/0004-13", ini:"2021-08-15",fim:"2028-07-14",val:5035.71, dia:15,idx:"IPCA", com:10,per:40,rej:"2026-05-15"},
  {id:"20529",     im:2063, grupo:"EJDD",loc:"VEGA SEUL AUTOMOTORES",         cpf:"29.037.515/0009-03", ini:"2025-02-25",fim:"2027-08-24",val:13500.00,dia:25,idx:"IGP-M",com:7, per:30,rej:"2026-03-25"},
  {id:"20864/0448",im:11417,grupo:"EJDD",loc:"JUMP RETIFICACOES LTDA",        cpf:"64.342.947/0001-63", ini:"2026-02-15",fim:"2028-08-14",val:5500.00, dia:15,idx:"IGP-M",com:7, per:20,rej:"2026-01-05"},
  {id:"9634",      im:1812, grupo:"EJDD",loc:"COOP. CREDITO ARACOOP",         cpf:"03.320.525/0001-00", ini:"2023-01-01",fim:"2025-12-31",val:12396.07,dia:1, idx:"IPC",  com:8, per:40,rej:"2026-02-01"},
  {id:"17979",     im:318,  grupo:"EJDD",loc:"CENTER HOSPITALAR LTDA",        cpf:"04.200.883/0001-34", ini:"2022-10-15",fim:"2025-10-14",val:7197.40, dia:15,idx:"IGP-M",com:5, per:10,rej:"2025-11-15"},
  // Edevaldo
  {id:"20901/0449",im:11301,grupo:"Edevaldo",loc:"CONSORCIO JUSTICA DO AMAPA",cpf:"63.264.012/0001-43", ini:"2026-03-05",fim:"2026-09-04",val:3300.00, dia:5, idx:"IGP-M",com:0, per:0, rej:"2026-02-05"},
  {id:"20693/0432",im:11041,grupo:"Edevaldo",loc:"SILVIA DANTAS ROCHA",       cpf:"439.670.002-49",     ini:"2025-08-11",fim:"2028-02-10",val:5000.00, dia:11,idx:"IGP-M",com:7, per:20,rej:"2025-08-11"},
  {id:"17685",     im:1694, grupo:"Edevaldo",loc:"M G DA SILVA EIRELE",       cpf:"04.324.849/0001-71", ini:"2022-07-20",fim:"2026-07-19",val:8554.97, dia:20,idx:"IGP-M",com:10,per:40,rej:"2025-08-20"},
  {id:"20310",     im:1373, grupo:"Edevaldo",loc:"MARCIO ANDRE SOUSA GOMES",  cpf:"412.967.453-68",     ini:"2024-07-26",fim:"2027-01-25",val:8500.00, dia:26,idx:"IPC",  com:8, per:20,rej:"2025-07-18"},
  {id:"20263",     im:1231, grupo:"Edevaldo",loc:"IVANA PEREIRA DE ARAÚJO",   cpf:"016.923.212-34",     ini:"2024-06-20",fim:"2026-12-19",val:1365.13, dia:20,idx:"IPC",  com:10,per:20,rej:"2025-06-20"},
];

/* gerar parcelas dos últimos 6 meses + próximos 2 */
const gerarParcelas = () => {
  const pags = [];
  CONTRATOS_BASE.forEach(c => {
    const fim = new Date(c.fim);
    let cur = new Date(new Date(c.ini).getFullYear(), new Date(c.ini).getMonth(), c.dia);
    let i = 0;
    while (cur <= fim && cur <= addM(HOJE,2)) {
      const mAtual = cur.getMonth()===HOJE.getMonth()&&cur.getFullYear()===HOJE.getFullYear();
      const passado = cur < HOJE && !mAtual;
      const st = passado ? (Math.random()>0.1?"pago":"atrasado") : "pendente";
      pags.push({
        id:`${c.id}||${i++}`,
        cId:c.id, imId:c.im, grupo:c.grupo,
        loc:c.loc, val:c.val,
        venc:toStr(cur), st,
        pgtoEm: st==="pago" ? toStr(new Date(cur.getTime()-Math.random()*5*86400000)) : null,
        obs:""
      });
      cur = addM(cur,1);
    }
  });
  return pags;
};

/* ─── Componentes UI ──────────────────────────────────────────────────── */
const S = {
  card: {background:"#13151f",border:"1px solid #1e2235",borderRadius:16,padding:24},
  row:  {display:"flex",gap:14,flexWrap:"wrap"},
};

const Btn = ({label, onClick, v="p", s, disabled}) => {
  const base = {padding:"9px 18px",borderRadius:10,fontSize:12,fontWeight:700,cursor:disabled?"not-allowed":"pointer",fontFamily:"inherit",opacity:disabled?0.5:1,transition:"opacity .15s"};
  const vs = {
    p: {...base,background:"#3b4fd8",color:"#fff",border:"none"},
    g: {...base,background:"transparent",color:"#8899bb",border:"1px solid #1e2235"},
    d: {...base,background:"transparent",color:"#f87171",border:"1px solid #f8717155"},
    gr:{...base,background:"#14532d",color:"#4ade80",border:"1px solid #4ade8044"},
    y: {...base,background:"#422006",color:"#fbbf24",border:"1px solid #fbbf2444"},
  };
  return <button onClick={onClick} disabled={disabled} style={{...vs[v],...s}}>{label}</button>;
};

const Badge = ({st}) => {
  const m = {pago:{bg:"#14532d",c:"#4ade80",l:"Pago"},atrasado:{bg:"#450a0a",c:"#f87171",l:"Atrasado"},pendente:{bg:"#422006",c:"#fbbf24",l:"Pendente"},ativo:{bg:"#14532d",c:"#4ade80",l:"Ativo"},encerrado:{bg:"#450a0a",c:"#f87171",l:"Encerrado"}};
  const x = m[st]||m.pendente;
  return <span style={{background:x.bg,color:x.c,padding:"3px 11px",borderRadius:20,fontSize:11,fontWeight:700,whiteSpace:"nowrap"}}>{x.l}</span>;
};

const Tag = ({g}) => {
  const e = g==="EJDD";
  return <span style={{fontSize:10,background:e?"#1e2a50":"#0f2a1a",color:e?"#7b8ff0":"#4ade80",padding:"2px 9px",borderRadius:20,fontWeight:700,whiteSpace:"nowrap"}}>{g}</span>;
};

const KPI = ({label,value,sub,cor,mini}) => (
  <div style={{...S.card,flex:1,minWidth:mini?120:150}}>
    <div style={{fontSize:10,color:"#667799",fontWeight:700,letterSpacing:1,textTransform:"uppercase",marginBottom:8}}>{label}</div>
    <div style={{fontSize:mini?18:22,fontWeight:800,color:cor||"#e2e4f0",lineHeight:1}}>{value}</div>
    {sub&&<div style={{fontSize:11,color:"#445566",marginTop:6}}>{sub}</div>}
  </div>
);

const Modal = ({title,onClose,children,wide}) => (
  <div onClick={onClose} style={{position:"fixed",inset:0,background:"#00000099",zIndex:200,display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
    <div onClick={e=>e.stopPropagation()} style={{background:"#13151f",border:"1px solid #1e2235",borderRadius:20,padding:32,width:wide?720:560,maxHeight:"90vh",overflowY:"auto"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:24}}>
        <span style={{fontSize:16,fontWeight:800}}>{title}</span>
        <button onClick={onClose} style={{background:"none",border:"none",color:"#667799",fontSize:22,cursor:"pointer",lineHeight:1}}>✕</button>
      </div>
      {children}
    </div>
  </div>
);

const TT = {contentStyle:{background:"#1a1d2e",border:"1px solid #1e2235",borderRadius:10,fontFamily:"Montserrat",fontSize:12}};

/* ─── CONCILIAÇÃO (página principal) ─────────────────────────────────── */
function Conciliacao({pags, setPags}) {
  const [mes, setMes]       = useState(mesAtual());
  const [grFiltro, setGr]   = useState("todos");
  const [stFiltro, setSt]   = useState("todos");
  const [modalPag, setMP]   = useState(null); // parcela selecionada
  const [obsTemp, setObs]   = useState("");
  const [dtTemp, setDt]     = useState("");
  const [modalObs, setMObs] = useState(null);

  const lista = useMemo(() => pags.filter(p => {
    const mOk = p.venc.startsWith(mes);
    const gOk = grFiltro==="todos"||p.grupo===grFiltro;
    const sOk = stFiltro==="todos"||p.st===stFiltro;
    return mOk&&gOk&&sOk;
  }),[pags,mes,grFiltro,stFiltro]);

  const tot   = lista.reduce((s,p)=>s+p.val,0);
  const pago  = lista.filter(p=>p.st==="pago").reduce((s,p)=>s+p.val,0);
  const atras = lista.filter(p=>p.st==="atrasado");

  const marcar = useCallback((id,st) => {
    setPags(prev=>prev.map(p=>p.id===id?{...p,st,pgtoEm:st==="pago"?toStr(HOJE):null}:p));
  },[setPags]);

  const abrirRegistro = (p) => {
    setMP(p);
    setObs(p.obs||"");
    setDt(p.pgtoEm||toStr(HOJE));
  };

  const confirmarPagamento = () => {
    setPags(prev=>prev.map(p=>p.id===modalPag.id?{...p,st:"pago",pgtoEm:dtTemp||toStr(HOJE),obs:obsTemp}:p));
    setMP(null);
  };

  const [mesLabel] = useMemo(()=>{
    const [y,m] = mes.split("-");
    return [`${MES_N[Number(m)-1]} ${y}`];
  },[mes]);

  return (
    <div style={{display:"flex",flexDirection:"column",gap:22}}>
      {/* Cabeçalho */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:12}}>
        <div>
          <h2 style={{fontSize:22,fontWeight:800,marginBottom:4}}>Conciliação Mensal</h2>
          <p style={{fontSize:13,color:"#667799"}}>{mesLabel}</p>
        </div>
        <div style={{display:"flex",gap:8,flexWrap:"wrap",alignItems:"center"}}>
          <input type="month" value={mes} onChange={e=>setMes(e.target.value)}
            style={{background:"#1a1d2e",border:"1px solid #1e2235",borderRadius:10,padding:"8px 12px",color:"#e2e4f0",fontSize:12,fontFamily:"inherit",outline:"none"}}/>
          {["todos","EJDD","Edevaldo"].map(g=>(
            <Btn key={g} label={g==="todos"?"Todos":g} onClick={()=>setGr(g)} v={grFiltro===g?"p":"g"} s={{padding:"8px 14px",fontSize:11}}/>
          ))}
          {["todos","pendente","pago","atrasado"].map(s=>(
            <Btn key={s} label={s==="todos"?"Todos":s.charAt(0).toUpperCase()+s.slice(1)} onClick={()=>setSt(s)} v={stFiltro===s?"p":"g"} s={{padding:"8px 14px",fontSize:11}}/>
          ))}
        </div>
      </div>

      {/* KPIs do mês */}
      <div style={S.row}>
        <KPI label="Total Esperado" value={ptBR(tot)} cor="#e2e4f0"/>
        <KPI label="Recebido" value={ptBR(pago)} cor="#4ade80" sub={`${lista.filter(p=>p.st==="pago").length} parcelas`}/>
        <KPI label="A Receber" value={ptBR(tot-pago)} cor="#fbbf24" sub={`${lista.filter(p=>p.st!=="pago").length} parcelas`}/>
        <KPI label="Atrasados" value={atras.length} cor={atras.length>0?"#f87171":"#4ade80"} sub="parcelas"/>
        <KPI label="% Recebido" value={`${tot>0?Math.round(pago/tot*100):0}%`} cor="#7b8ff0"/>
      </div>

      {/* Alertas de atraso */}
      {atras.length>0&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {atras.map(p=>(
            <div key={p.id} style={{background:"#1a0808",border:"1px solid #f8717133",borderRadius:12,padding:"12px 18px",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}}>
              <span style={{fontSize:13}}>⚠️ <strong>{p.loc}</strong> — venc. {dataBR(p.venc)} em atraso</span>
              <div style={{display:"flex",gap:8}}>
                <span style={{color:"#f87171",fontWeight:700,fontSize:13}}>{ptBR(p.val)}</span>
                <Btn label="Registrar pagamento" onClick={()=>abrirRegistro(p)} v="gr" s={{padding:"5px 12px",fontSize:11}}/>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tabela */}
      <div style={{...S.card,padding:0,overflow:"hidden"}}>
        <table style={{width:"100%",borderCollapse:"collapse"}}>
          <thead>
            <tr style={{background:"#0f1118"}}>
              {["Locatário","Grupo","Imóvel","Vencimento","Valor","Status","Pago em","Ação"].map(h=>(
                <th key={h} style={{padding:"13px 16px",textAlign:"left",fontSize:10,color:"#667799",fontWeight:700,letterSpacing:0.8,textTransform:"uppercase",whiteSpace:"nowrap"}}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {lista.length===0&&(
              <tr><td colSpan={8} style={{padding:40,textAlign:"center",color:"#445566",fontSize:13}}>Nenhum registro para este mês.</td></tr>
            )}
            {lista.map((p,i)=>(
              <tr key={p.id} style={{borderTop:"1px solid #1a1d2e",background:i%2===0?"transparent":"#0d0f18"}}>
                <td style={{padding:"12px 16px",fontSize:12,fontWeight:600,maxWidth:180}}>
                  <div style={{overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.loc}</div>
                  {p.obs&&<div style={{fontSize:10,color:"#667799",marginTop:2}}>📝 {p.obs.slice(0,30)}{p.obs.length>30?"…":""}</div>}
                </td>
                <td style={{padding:"12px 16px"}}><Tag g={p.grupo}/></td>
                <td style={{padding:"12px 16px",fontSize:11,color:"#667799",maxWidth:160}}>
                  <div style={{overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{IMOVEIS[p.imId]?.end?.split(",")[0]}</div>
                </td>
                <td style={{padding:"12px 16px",fontSize:12,whiteSpace:"nowrap"}}>{dataBR(p.venc)}</td>
                <td style={{padding:"12px 16px",fontSize:13,fontWeight:700,whiteSpace:"nowrap"}}>{ptBR(p.val)}</td>
                <td style={{padding:"12px 16px"}}><Badge st={p.st}/></td>
                <td style={{padding:"12px 16px",fontSize:11,color:"#667799"}}>{p.pgtoEm?dataBR(p.pgtoEm):"—"}</td>
                <td style={{padding:"12px 16px"}}>
                  <div style={{display:"flex",gap:6,flexWrap:"nowrap"}}>
                    {p.st!=="pago"&&<Btn label="✓ Pago" onClick={()=>abrirRegistro(p)} v="gr" s={{padding:"5px 11px",fontSize:11}}/>}
                    {p.st==="pago"&&<Btn label="Reverter" onClick={()=>marcar(p.id,"pendente")} v="g" s={{padding:"5px 11px",fontSize:11}}/>}
                    {p.st==="pendente"&&<Btn label="Atraso" onClick={()=>marcar(p.id,"atrasado")} v="d" s={{padding:"5px 11px",fontSize:11}}/>}
                    <Btn label="📝" onClick={()=>setMObs(p)} v="g" s={{padding:"5px 9px",fontSize:11}}/>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal registrar pagamento */}
      {modalPag&&(
        <Modal title="Registrar Pagamento" onClose={()=>setMP(null)}>
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <div style={{background:"#0d0f18",borderRadius:12,padding:16}}>
              <div style={{fontSize:13,fontWeight:700,marginBottom:4}}>{modalPag.loc}</div>
              <div style={{fontSize:12,color:"#667799"}}>Vencimento: {dataBR(modalPag.venc)} · {ptBR(modalPag.val)}</div>
            </div>
            <label style={{display:"flex",flexDirection:"column",gap:6}}>
              <span style={{fontSize:11,color:"#667799",fontWeight:700,textTransform:"uppercase",letterSpacing:0.5}}>Data do Recebimento</span>
              <input type="date" value={dtTemp} onChange={e=>setDt(e.target.value)}
                style={{background:"#1a1d2e",border:"1px solid #1e2235",borderRadius:10,padding:"10px 14px",color:"#e2e4f0",fontSize:13,fontFamily:"inherit",outline:"none"}}/>
            </label>
            <label style={{display:"flex",flexDirection:"column",gap:6}}>
              <span style={{fontSize:11,color:"#667799",fontWeight:700,textTransform:"uppercase",letterSpacing:0.5}}>Observação (opcional)</span>
              <textarea value={obsTemp} onChange={e=>setObs(e.target.value)} rows={3} placeholder="Ex: pago via PIX, pago parcialmente..."
                style={{background:"#1a1d2e",border:"1px solid #1e2235",borderRadius:10,padding:"10px 14px",color:"#e2e4f0",fontSize:13,fontFamily:"inherit",outline:"none",resize:"vertical"}}/>
            </label>
            <div style={{display:"flex",gap:12,justifyContent:"flex-end",marginTop:8}}>
              <Btn label="Cancelar" onClick={()=>setMP(null)} v="g"/>
              <Btn label="✓ Confirmar Pagamento" onClick={confirmarPagamento} v="gr"/>
            </div>
          </div>
        </Modal>
      )}

      {/* Modal observação */}
      {modalObs&&(
        <Modal title="Observação" onClose={()=>setMObs(null)}>
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <div style={{fontSize:13,fontWeight:600}}>{modalObs.loc}</div>
            <textarea defaultValue={modalObs.obs} id="obsInput" rows={4} placeholder="Digite uma observação..."
              style={{background:"#1a1d2e",border:"1px solid #1e2235",borderRadius:10,padding:"10px 14px",color:"#e2e4f0",fontSize:13,fontFamily:"inherit",outline:"none",resize:"vertical"}}/>
            <div style={{display:"flex",gap:12,justifyContent:"flex-end"}}>
              <Btn label="Cancelar" onClick={()=>setMObs(null)} v="g"/>
              <Btn label="Salvar" onClick={()=>{
                const v = document.getElementById("obsInput").value;
                setPags(prev=>prev.map(p=>p.id===modalObs.id?{...p,obs:v}:p));
                setMObs(null);
              }} v="p"/>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

/* ─── RELATÓRIO PDF ───────────────────────────────────────────────────── */
function Relatorio({pags}) {
  const [mes, setMes] = useState(mesAtual());

  const [mesLabel] = useMemo(()=>{
    const [y,m] = mes.split("-");
    return [`${MES_N[Number(m)-1]} ${y}`];
  },[mes]);

  const doMes = useMemo(()=>pags.filter(p=>p.venc.startsWith(mes)),[pags,mes]);

  const ejddPags = doMes.filter(p=>p.grupo==="EJDD");
  const edevPags = doMes.filter(p=>p.grupo==="Edevaldo");

  const calcGrupo = (lista) => ({
    total:    lista.reduce((s,p)=>s+p.val,0),
    pago:     lista.filter(p=>p.st==="pago").reduce((s,p)=>s+p.val,0),
    atrasado: lista.filter(p=>p.st==="atrasado").reduce((s,p)=>s+p.val,0),
    pendente: lista.filter(p=>p.st==="pendente").reduce((s,p)=>s+p.val,0),
    qtdPago:  lista.filter(p=>p.st==="pago").length,
    qtdAtr:   lista.filter(p=>p.st==="atrasado").length,
    qtdPend:  lista.filter(p=>p.st==="pendente").length,
  });

  const ejddStats = calcGrupo(ejddPags);
  const edevStats = calcGrupo(edevPags);
  const totalGeral = ejddStats.total + edevStats.total;
  const pagoGeral  = ejddStats.pago  + edevStats.pago;
  const atrasGeral = ejddStats.atrasado + edevStats.atrasado;

  const imprimir = () => window.print();

  const tabelaRel = (lista, stats) => (
    <table style={{width:"100%",borderCollapse:"collapse",fontSize:12,marginTop:12}}>
      <thead>
        <tr style={{background:"#1a1d2e"}}>
          {["Locatário","Vencimento","Valor","Status","Recebido em","Obs."].map(h=>(
            <th key={h} style={{padding:"10px 12px",textAlign:"left",fontSize:10,color:"#667799",fontWeight:700,letterSpacing:0.5,textTransform:"uppercase"}}>{h}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {lista.map((p,i)=>(
          <tr key={p.id} style={{borderTop:"1px solid #1e2235",background:i%2===0?"transparent":"#0d0f18"}}>
            <td style={{padding:"10px 12px",fontWeight:600,fontSize:12}}>{p.loc}</td>
            <td style={{padding:"10px 12px",fontSize:12}}>{dataBR(p.venc)}</td>
            <td style={{padding:"10px 12px",fontWeight:700,fontSize:13}}>{ptBR(p.val)}</td>
            <td style={{padding:"10px 12px"}}><Badge st={p.st}/></td>
            <td style={{padding:"10px 12px",fontSize:11,color:"#667799"}}>{p.pgtoEm?dataBR(p.pgtoEm):"—"}</td>
            <td style={{padding:"10px 12px",fontSize:11,color:"#667799"}}>{p.obs||"—"}</td>
          </tr>
        ))}
        <tr style={{borderTop:"2px solid #3b4fd8",background:"#0f1118"}}>
          <td colSpan={2} style={{padding:"10px 12px",fontWeight:800,fontSize:12}}>TOTAL</td>
          <td style={{padding:"10px 12px",fontWeight:800,fontSize:13,color:"#4ade80"}}>{ptBR(stats.total)}</td>
          <td colSpan={3} style={{padding:"10px 12px",fontSize:11,color:"#667799"}}>
            Pago: {ptBR(stats.pago)} · Atrasado: {ptBR(stats.atrasado)} · Pendente: {ptBR(stats.pendente)}
          </td>
        </tr>
      </tbody>
    </table>
  );

  return (
    <div style={{display:"flex",flexDirection:"column",gap:22}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:12}} className="no-print">
        <div>
          <h2 style={{fontSize:22,fontWeight:800,marginBottom:4}}>Relatório Mensal</h2>
          <p style={{fontSize:13,color:"#667799"}}>Pronto para imprimir ou salvar em PDF</p>
        </div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <input type="month" value={mes} onChange={e=>setMes(e.target.value)}
            style={{background:"#1a1d2e",border:"1px solid #1e2235",borderRadius:10,padding:"8px 12px",color:"#e2e4f0",fontSize:12,fontFamily:"inherit",outline:"none"}}/>
          <Btn label="🖨️ Imprimir / Salvar PDF" onClick={imprimir} v="p"/>
        </div>
      </div>

      {/* Área do relatório */}
      <div className="print-area">
        {/* Cabeçalho do relatório */}
        <div style={{...S.card,marginBottom:20,borderColor:"#3b4fd855"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:12}}>
            <div>
              <div style={{fontSize:20,fontWeight:800,color:"#7b8ff0"}}>Relatório de Aluguéis</div>
              <div style={{fontSize:14,color:"#667799",marginTop:2}}>{mesLabel} · Gerado em {dataBR(toStr(HOJE))}</div>
            </div>
            <div style={{textAlign:"right"}}>
              <div style={{fontSize:11,color:"#667799"}}>EJDD Empreendimentos Imobiliários</div>
              <div style={{fontSize:11,color:"#667799"}}>Edevaldo Xavier de Oliveira</div>
            </div>
          </div>
        </div>

        {/* Resumo geral */}
        <div style={{...S.card,marginBottom:20}}>
          <div style={{fontSize:13,fontWeight:800,marginBottom:16,color:"#7b8ff0",letterSpacing:0.5}}>RESUMO CONSOLIDADO</div>
          <div style={S.row}>
            <KPI label="Total Carteira" value={ptBR(totalGeral)} cor="#fff" mini/>
            <KPI label="Total Recebido" value={ptBR(pagoGeral)} cor="#4ade80" sub={`${doMes.filter(p=>p.st==="pago").length} pag.`} mini/>
            <KPI label="Em Atraso" value={ptBR(atrasGeral)} cor="#f87171" sub={`${doMes.filter(p=>p.st==="atrasado").length} pag.`} mini/>
            <KPI label="EJDD" value={ptBR(ejddStats.total)} cor="#7b8ff0" sub={`Recebido: ${ptBR(ejddStats.pago)}`} mini/>
            <KPI label="Edevaldo" value={ptBR(edevStats.total)} cor="#4ade80" sub={`Recebido: ${ptBR(edevStats.pago)}`} mini/>
            <KPI label="% Recebimento" value={`${totalGeral>0?Math.round(pagoGeral/totalGeral*100):0}%`} cor="#fbbf24" mini/>
          </div>
        </div>

        {/* EJDD */}
        <div style={{...S.card,marginBottom:20}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:4,flexWrap:"wrap",gap:8}}>
            <div style={{fontSize:14,fontWeight:800,color:"#7b8ff0"}}>EJDD EMPREENDIMENTOS IMOBILIÁRIOS LTDA</div>
            <div style={{display:"flex",gap:16,fontSize:12}}>
              <span style={{color:"#4ade80"}}>✓ {ejddStats.qtdPago} pagos</span>
              <span style={{color:"#f87171"}}>⚠ {ejddStats.qtdAtr} atrasados</span>
              <span style={{color:"#fbbf24"}}>⏳ {ejddStats.qtdPend} pendentes</span>
            </div>
          </div>
          {tabelaRel(ejddPags, ejddStats)}
        </div>

        {/* Edevaldo */}
        <div style={{...S.card,marginBottom:20}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:4,flexWrap:"wrap",gap:8}}>
            <div style={{fontSize:14,fontWeight:800,color:"#4ade80"}}>EDEVALDO XAVIER DE OLIVEIRA</div>
            <div style={{display:"flex",gap:16,fontSize:12}}>
              <span style={{color:"#4ade80"}}>✓ {edevStats.qtdPago} pagos</span>
              <span style={{color:"#f87171"}}>⚠ {edevStats.qtdAtr} atrasados</span>
              <span style={{color:"#fbbf24"}}>⏳ {edevStats.qtdPend} pendentes</span>
            </div>
          </div>
          {tabelaRel(edevPags, edevStats)}
        </div>

        {/* Rodapé */}
        <div style={{textAlign:"center",fontSize:11,color:"#445566",marginTop:8}}>
          Relatório gerado automaticamente · {HOJE.toLocaleDateString("pt-BR",{day:"numeric",month:"long",year:"numeric"})}
        </div>
      </div>
    </div>
  );
}

/* ─── CONTRATOS ───────────────────────────────────────────────────────── */
const FORM_VAZIO = {id:"",im:"",grupo:"EJDD",loc:"",cpf:"",ini:"",fim:"",val:"",dia:"",idx:"IGP-M",com:"",per:"",rej:"",endNovo:"",tipoNovo:"Comercial"};

function Contratos({cts,setCts,setPags}) {
  const [f,    setF]    = useState("todos");
  const [det,  setDet]  = useState(null);
  const [novo, setNovo] = useState(false);
  const [form, setForm] = useState(FORM_VAZIO);
  const [erro, setErro] = useState("");

  const fv = (k,v) => setForm(p=>({...p,[k]:v}));

  const lista = useMemo(()=>{
    if(f==="EJDD")     return cts.filter(c=>c.grupo==="EJDD");
    if(f==="Edevaldo") return cts.filter(c=>c.grupo==="Edevaldo");
    if(f==="Vencendo") return cts.filter(c=>{const d=dias(c.fim);return d>=0&&d<=60&&c.status==="ativo";});
    return cts;
  },[cts,f]);

  const salvarNovo = () => {
    if(!form.id||!form.loc||!form.ini||!form.fim||!form.val||!form.dia) {
      setErro("Preencha todos os campos obrigatórios (*).");
      return;
    }
    if(cts.find(c=>c.id===form.id)) { setErro("Já existe um contrato com este número."); return; }

    const imId = form.im ? Number(form.im) : Date.now();
    // Se digitou endereço novo, adiciona ao IMOVEIS em memória
    if(form.endNovo && !IMOVEIS[imId]) {
      IMOVEIS[imId] = {end: form.endNovo, tipo: form.tipoNovo};
    }

    const novo = {
      id:     form.id,
      im:     imId,
      grupo:  form.grupo,
      loc:    form.loc,
      cpf:    form.cpf,
      ini:    form.ini,
      fim:    form.fim,
      val:    Number(form.val),
      dia:    Number(form.dia),
      idx:    form.idx,
      com:    Number(form.com)||0,
      per:    Number(form.per)||0,
      rej:    form.rej||form.ini,
      status: "ativo",
    };

    // Gerar parcelas futuras para o novo contrato
    const novasParcelas = [];
    const fim = new Date(novo.fim);
    let cur = new Date(new Date(novo.ini).getFullYear(), new Date(novo.ini).getMonth(), novo.dia);
    let i = 0;
    while(cur <= fim && cur <= addM(HOJE,2)) {
      const mAtual = cur.getMonth()===HOJE.getMonth()&&cur.getFullYear()===HOJE.getFullYear();
      const passado = cur < HOJE && !mAtual;
      novasParcelas.push({
        id:`${novo.id}||${i++}`,
        cId:novo.id, imId:imId, grupo:novo.grupo,
        loc:novo.loc, val:novo.val,
        venc:toStr(cur), st: passado?"atrasado":"pendente",
        pgtoEm:null, obs:""
      });
      cur = addM(cur,1);
    }

    setCts(p=>[...p,novo]);
    setPags(p=>[...p,...novasParcelas]);
    setNovo(false);
    setForm(FORM_VAZIO);
    setErro("");
  };

  const campo = (label, key, type="text", obrig=false, opts=null) => (
    <label style={{display:"flex",flexDirection:"column",gap:5}}>
      <span style={{fontSize:10,color:"#667799",fontWeight:700,textTransform:"uppercase",letterSpacing:0.5}}>{label}{obrig?" *":""}</span>
      {opts ? (
        <select value={form[key]} onChange={e=>fv(key,e.target.value)}
          style={{background:"#1a1d2e",border:"1px solid #1e2235",borderRadius:10,padding:"10px 12px",color:"#e2e4f0",fontSize:13,fontFamily:"inherit",outline:"none"}}>
          {opts.map(o=><option key={o} value={o}>{o}</option>)}
        </select>
      ) : (
        <input type={type} value={form[key]} onChange={e=>fv(key,e.target.value)} placeholder={obrig?"Obrigatório":""}
          style={{background:"#1a1d2e",border:"1px solid #1e2235",borderRadius:10,padding:"10px 12px",color:"#e2e4f0",fontSize:13,fontFamily:"inherit",outline:"none"}}/>
      )}
    </label>
  );

  return (
    <div style={{display:"flex",flexDirection:"column",gap:22}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:12}}>
        <h2 style={{fontSize:22,fontWeight:800}}>Contratos — {lista.length} registro(s)</h2>
        <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
          {["todos","EJDD","Edevaldo","Vencendo"].map(x=>(
            <Btn key={x} label={x==="todos"?"Todos":x} onClick={()=>setF(x)} v={f===x?"p":"g"} s={{padding:"8px 14px",fontSize:11}}/>
          ))}
          <Btn label="+ Novo Contrato" onClick={()=>{setNovo(true);setErro("");setForm(FORM_VAZIO);}} v="p" s={{padding:"8px 16px",fontSize:11}}/>
        </div>
      </div>

      {/* Modal novo contrato */}
      {novo&&(
        <Modal title="Novo Contrato" onClose={()=>setNovo(false)} wide>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
            {campo("Nº do Contrato","id","text",true)}
            {campo("Grupo / Locador","grupo","text",true,["EJDD","Edevaldo"])}
            <div style={{gridColumn:"1/-1"}}>{campo("Nome do Locatário","loc","text",true)}</div>
            {campo("CPF / CNPJ","cpf")}
            {campo("Valor Mensal (R$)","val","number",true)}
            {campo("Dia de Vencimento","dia","number",true)}
            {campo("Início","ini","date",true)}
            {campo("Término","fim","date",true)}
            {campo("Índice de Reajuste","idx","text",false,["IGP-M","IPCA","IPC","INPC","Fixo"])}
            {campo("Comissão (%)","com","number")}
            {campo("% Intermediação","per","number")}
            {campo("Último Reajuste","rej","date")}
            <div style={{gridColumn:"1/-1",borderTop:"1px solid #1e2235",paddingTop:14,marginTop:4}}>
              <div style={{fontSize:11,color:"#667799",fontWeight:700,marginBottom:10,textTransform:"uppercase",letterSpacing:0.5}}>Imóvel</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
                <label style={{display:"flex",flexDirection:"column",gap:5}}>
                  <span style={{fontSize:10,color:"#667799",fontWeight:700,textTransform:"uppercase",letterSpacing:0.5}}>Imóvel existente (ID)</span>
                  <select value={form.im} onChange={e=>fv("im",e.target.value)}
                    style={{background:"#1a1d2e",border:"1px solid #1e2235",borderRadius:10,padding:"10px 12px",color:"#e2e4f0",fontSize:12,fontFamily:"inherit",outline:"none"}}>
                    <option value="">— Novo imóvel —</option>
                    {Object.entries(IMOVEIS).map(([id,im])=>(
                      <option key={id} value={id}>#{id} — {im.end.slice(0,35)}</option>
                    ))}
                  </select>
                </label>
                {campo("Tipo","tipoNovo","text",false,["Comercial","Residencial","Industrial"])}
                {!form.im&&<div style={{gridColumn:"1/-1"}}>{campo("Endereço do novo imóvel","endNovo")}</div>}
              </div>
            </div>
          </div>
          {erro&&<div style={{marginTop:12,color:"#f87171",fontSize:12,fontWeight:600}}>⚠ {erro}</div>}
          <div style={{display:"flex",gap:12,justifyContent:"flex-end",marginTop:20}}>
            <Btn label="Cancelar" onClick={()=>setNovo(false)} v="g"/>
            <Btn label="✓ Salvar Contrato" onClick={salvarNovo} v="p"/>
          </div>
        </Modal>
      )}

      {lista.map(c=>{
        const im=IMOVEIS[c.im]||{};
        const d=dias(c.fim);
        const urg=d>=0&&d<=60&&c.status==="ativo";
        return (
          <div key={c.id} onClick={()=>setDet(c)} style={{...S.card,display:"flex",gap:16,alignItems:"center",cursor:"pointer",borderColor:urg?"#fbbf2444":"#1e2235"}}>
            <div style={{width:44,height:44,background:c.grupo==="EJDD"?"#1e2a50":"#0f2a1a",borderRadius:12,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0}}>
              {im.tipo==="Residencial"?"🏠":"🏢"}
            </div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:3,flexWrap:"wrap"}}>
                <span style={{fontWeight:700,fontSize:13}}>{c.loc}</span>
                <Tag g={c.grupo}/>
              </div>
              <div style={{fontSize:11,color:"#667799",marginBottom:2}}>{im.end}</div>
              <div style={{fontSize:11,color:"#445566"}}>Contrato {c.id} · Vence {dataBR(c.fim)} · Dia {c.dia} · {c.idx}</div>
            </div>
            <div style={{textAlign:"right",flexShrink:0}}>
              <div style={{fontWeight:800,fontSize:16,color:"#4ade80"}}>{ptBR(c.val)}<span style={{fontSize:11,fontWeight:400,color:"#445566"}}>/mês</span></div>
              <div style={{fontSize:11,color:"#667799",marginTop:2}}>Com. {c.com}% · Int. {c.per}%</div>
              {urg&&<div style={{fontSize:10,color:"#fbbf24",fontWeight:700,marginTop:3}}>⏳ {d}d para vencer</div>}
            </div>
            <Badge st={c.status}/>
          </div>
        );
      })}

      {det&&(
        <Modal title={`Contrato ${det.id}`} onClose={()=>setDet(null)}>
          {[
            ["Contrato",det.id],["Imóvel Nº",det.im],["Grupo",det.grupo],
            ["Locatário",det.loc],["CPF/CNPJ",det.cpf],
            ["Endereço",IMOVEIS[det.im]?.end],["Tipo",IMOVEIS[det.im]?.tipo],
            ["Início",dataBR(det.ini)],["Término",dataBR(det.fim)],
            ["Dias p/ vencer",`${dias(det.fim)} dias`],
            ["Dia Vencimento",det.dia],["Índice",det.idx],
            ["Valor Mensal",ptBR(det.val)],["% Intermediação",`${det.per}%`],
            ["Comissão",`${det.com}%`],["Últ. Reajuste",dataBR(det.rej)],
          ].map(([k,v])=>(
            <div key={k} style={{display:"flex",justifyContent:"space-between",borderBottom:"1px solid #1e2235",paddingBottom:8,marginBottom:8}}>
              <span style={{fontSize:12,color:"#667799",fontWeight:600}}>{k}</span>
              <span style={{fontSize:12,fontWeight:500,textAlign:"right",maxWidth:300}}>{v}</span>
            </div>
          ))}
          <div style={{marginTop:12}}>
            <Btn label="Encerrar Contrato" v="d" onClick={()=>{setCts(p=>p.map(x=>x.id===det.id?{...x,status:"encerrado"}:x));setDet(null);}}/>
          </div>
        </Modal>
      )}
    </div>
  );
}

/* ─── DASHBOARD ───────────────────────────────────────────────────────── */
function Dashboard({cts, pags}) {
  const at   = cts.filter(c=>c.status==="ativo");
  const ejdd = at.filter(c=>c.grupo==="EJDD");
  const edev = at.filter(c=>c.grupo==="Edevaldo");
  const tE   = ejdd.reduce((s,c)=>s+c.val,0);
  const tV   = edev.reduce((s,c)=>s+c.val,0);
  const mk   = mesAtual();
  const recM = pags.filter(p=>p.venc.startsWith(mk)&&p.st==="pago").reduce((s,p)=>s+p.val,0);
  const atr  = pags.filter(p=>p.st==="atrasado");
  const v60  = at.filter(c=>{const d=dias(c.fim);return d>=0&&d<=60;});

  const bar6 = Array.from({length:6},(_,i)=>{
    const d=addM(HOJE,i-5);
    const k=toStr(d).slice(0,7);
    const e=pags.filter(p=>p.venc.startsWith(k)&&p.st==="pago"&&p.grupo==="EJDD").reduce((s,p)=>s+p.val,0);
    const v=pags.filter(p=>p.venc.startsWith(k)&&p.st==="pago"&&p.grupo==="Edevaldo").reduce((s,p)=>s+p.val,0);
    return {mes:MES_S[d.getMonth()],EJDD:e,Edevaldo:v};
  });

  const pieD=[{name:"EJDD",value:tE},{name:"Edevaldo",value:tV}];
  const PC=["#3b4fd8","#4ade80"];

  return (
    <div style={{display:"flex",flexDirection:"column",gap:22}}>
      <div>
        <h2 style={{fontSize:22,fontWeight:800,marginBottom:4}}>Dashboard</h2>
        <p style={{fontSize:13,color:"#667799"}}>{HOJE.toLocaleDateString("pt-BR",{weekday:"long",day:"numeric",month:"long",year:"numeric"})}</p>
      </div>

      <div style={S.row}>
        <KPI label="Contratos Ativos" value={at.length} sub={`EJDD: ${ejdd.length} · Edev: ${edev.length}`} cor="#7b8ff0"/>
        <KPI label="Carteira/Mês" value={ptBR(tE+tV)} cor="#fff"/>
        <KPI label="EJDD /Mês" value={ptBR(tE)} cor="#7b8ff0" sub={`${ejdd.length} contratos`}/>
        <KPI label="Edevaldo /Mês" value={ptBR(tV)} cor="#4ade80" sub={`${edev.length} contratos`}/>
        <KPI label="Recebido (mês)" value={ptBR(recM)} cor="#4ade80"/>
        <KPI label="Atrasados" value={atr.length} cor={atr.length>0?"#f87171":"#4ade80"}/>
      </div>

      {(atr.length>0||v60.length>0)&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {atr.slice(0,3).map(p=>(
            <div key={p.id} style={{background:"#1a0808",border:"1px solid #f8717133",borderRadius:12,padding:"12px 18px",display:"flex",justifyContent:"space-between",alignItems:"center",gap:8,flexWrap:"wrap"}}>
              <span style={{fontSize:13}}>⚠️ <strong>{p.loc}</strong> — {dataBR(p.venc)} em atraso</span>
              <span style={{color:"#f87171",fontWeight:700}}>{ptBR(p.val)}</span>
            </div>
          ))}
          {v60.map(c=>(
            <div key={c.id} style={{background:"#1a1200",border:"1px solid #fbbf2433",borderRadius:12,padding:"12px 18px",display:"flex",justifyContent:"space-between",alignItems:"center",gap:8,flexWrap:"wrap"}}>
              <span style={{fontSize:13}}>📅 <strong>{c.id}</strong> — {c.loc.slice(0,28)} vence em <strong>{dias(c.fim)} dias</strong></span>
              <span style={{color:"#fbbf24",fontWeight:700,fontSize:11}}>{dataBR(c.fim)}</span>
            </div>
          ))}
        </div>
      )}

      <div style={{display:"grid",gridTemplateColumns:"2fr 1fr",gap:20}}>
        <div style={S.card}>
          <div style={{fontSize:11,fontWeight:700,marginBottom:18,color:"#667799",letterSpacing:0.8}}>RECEITA RECEBIDA — ÚLTIMOS 6 MESES</div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={bar6} barSize={16} barGap={3}>
              <XAxis dataKey="mes" tick={{fill:"#445566",fontSize:11,fontFamily:"Montserrat"}} axisLine={false} tickLine={false}/>
              <YAxis hide/>
              <Tooltip formatter={v=>ptBR(v)} {...TT}/>
              <Bar dataKey="EJDD" fill="#3b4fd8" radius={[4,4,0,0]}/>
              <Bar dataKey="Edevaldo" fill="#4ade80" radius={[4,4,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
          <div style={{display:"flex",gap:20,fontSize:12,marginTop:10}}>
            <span style={{color:"#3b4fd8"}}>● EJDD</span>
            <span style={{color:"#4ade80"}}>● Edevaldo</span>
          </div>
        </div>
        <div style={S.card}>
          <div style={{fontSize:11,fontWeight:700,marginBottom:14,color:"#667799",letterSpacing:0.8}}>DISTRIBUIÇÃO MENSAL</div>
          <ResponsiveContainer width="100%" height={150}>
            <PieChart>
              <Pie data={pieD} cx="50%" cy="50%" innerRadius={42} outerRadius={68} paddingAngle={4} dataKey="value">
                {pieD.map((_,i)=><Cell key={i} fill={PC[i]}/>)}
              </Pie>
              <Tooltip formatter={v=>ptBR(v)} {...TT}/>
            </PieChart>
          </ResponsiveContainer>
          {pieD.map((d,i)=>(
            <div key={d.name} style={{display:"flex",justifyContent:"space-between",fontSize:12,marginTop:8}}>
              <span style={{color:PC[i]}}>● {d.name}</span><span>{ptBR(d.value)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── APP ROOT ────────────────────────────────────────────────────────── */
export default function App() {
  const [pg,  setPg]  = useState("conciliacao");
  const [cts, setCts] = useState(()=>CONTRATOS_BASE.map(c=>({...c,status:"ativo"})));
  const [pags,setPags] = useState(()=>gerarParcelas());

  const alertas = pags.filter(p=>p.st==="atrasado").length +
    cts.filter(c=>{const d=dias(c.fim);return d>=0&&d<=60&&c.status==="ativo";}).length;

  const carteira = cts.filter(c=>c.status==="ativo").reduce((s,c)=>s+c.val,0);
  const mesKey   = mesAtual();
  const recMes   = pags.filter(p=>p.venc.startsWith(mesKey)&&p.st==="pago").reduce((s,p)=>s+p.val,0);
  const pendMes  = pags.filter(p=>p.venc.startsWith(mesKey)&&p.st!=="pago").length;

  const nav = [
    {id:"dashboard",    label:"Dashboard",    icon:"📊"},
    {id:"conciliacao",  label:"Conciliação",  icon:"✅"},
    {id:"contratos",    label:"Contratos",    icon:"📄"},
    {id:"relatorio",    label:"Relatório PDF",icon:"🖨️"},
  ];

  return (
    <>
      <style>{G}</style>
      <div style={{minHeight:"100vh",background:"#0b0d14",display:"flex"}}>

        {/* Sidebar */}
        <div className="no-print" style={{width:224,background:"#0d1018",borderRight:"1px solid #1a1d2e",display:"flex",flexDirection:"column",position:"fixed",top:0,left:0,height:"100vh",padding:"28px 0"}}>
          <div style={{padding:"0 22px",marginBottom:28}}>
            <div style={{fontSize:16,fontWeight:800,color:"#fff",letterSpacing:-0.5}}>Aluguéis</div>
            <div style={{fontSize:10,color:"#3b4fd8",fontWeight:700,marginTop:2,letterSpacing:1}}>EJDD · EDEVALDO</div>
          </div>

          <nav style={{flex:1}}>
            {nav.map(n=>(
              <button key={n.id} onClick={()=>setPg(n.id)} style={{width:"100%",display:"flex",alignItems:"center",gap:11,padding:"11px 22px",background:pg===n.id?"#161b2e":"transparent",border:"none",borderLeft:pg===n.id?"3px solid #3b4fd8":"3px solid transparent",color:pg===n.id?"#e2e4f0":"#667799",cursor:"pointer",fontSize:13,fontWeight:pg===n.id?700:500,fontFamily:"inherit",textAlign:"left",transition:"all .15s"}}>
                <span style={{fontSize:16}}>{n.icon}</span>
                <span>{n.label}</span>
                {n.id==="dashboard"&&alertas>0&&(
                  <span style={{marginLeft:"auto",background:"#f87171",color:"#fff",borderRadius:20,fontSize:10,fontWeight:800,padding:"2px 7px"}}>{alertas}</span>
                )}
                {n.id==="conciliacao"&&pendMes>0&&(
                  <span style={{marginLeft:"auto",background:"#fbbf24",color:"#000",borderRadius:20,fontSize:10,fontWeight:800,padding:"2px 7px"}}>{pendMes}</span>
                )}
              </button>
            ))}
          </nav>

          {/* Resumo sidebar */}
          <div style={{padding:"16px 22px",borderTop:"1px solid #1a1d2e"}}>
            <div style={{fontSize:10,color:"#445566",marginBottom:4,fontWeight:700,letterSpacing:0.5}}>CARTEIRA / MÊS</div>
            <div style={{fontSize:16,fontWeight:800,color:"#4ade80"}}>{ptBR(carteira)}</div>
            <div style={{marginTop:8,display:"flex",flexDirection:"column",gap:3}}>
              <div style={{fontSize:11,color:"#445566"}}>Recebido: <span style={{color:"#4ade80",fontWeight:700}}>{ptBR(recMes)}</span></div>
              <div style={{fontSize:11,color:"#445566"}}>{cts.filter(c=>c.status==="ativo").length} contratos ativos</div>
            </div>
          </div>
        </div>

        {/* Conteúdo */}
        <div style={{marginLeft:224,flex:1,padding:"36px 36px 60px",maxWidth:"calc(100vw - 224px)"}}>
          {pg==="dashboard"   && <Dashboard cts={cts} pags={pags}/>}
          {pg==="conciliacao" && <Conciliacao pags={pags} setPags={setPags}/>}
          {pg==="contratos"   && <Contratos cts={cts} setCts={setCts} setPags={setPags}/>}
          {pg==="relatorio"   && <Relatorio pags={pags}/>}
        </div>
      </div>
    </>
  );
}

/* ── Login ── */
const USUARIOS = [
  { usuario: 'diogo', senha: 'ejdd2024', nome: 'Diogo' },
  { usuario: 'admin', senha: 'alugueis2024', nome: 'Administrador' },
]

function Login({ onLogin }) {
  const [usuario, setUsuario] = useState('')
  const [senha, setSenha]     = useState('')
  const [erro, setErro]       = useState('')
  const entrar = () => {
    const user = USUARIOS.find(u => u.usuario === usuario.trim().toLowerCase() && u.senha === senha)
    if (user) { onLogin(user) } else { setErro('Usuário ou senha incorretos.') }
  }
  const inp = { width:'100%', background:'#1a1d2e', border:'1px solid #2a2d40', borderRadius:12, padding:'13px 16px', color:'#e2e4f0', fontSize:14, fontFamily:'inherit', outline:'none' }
  return (
    <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'#0b0d14' }}>
      <div style={{ width:360, background:'#13151f', border:'1px solid #1e2235', borderRadius:24, padding:40 }}>
        <div style={{ textAlign:'center', marginBottom:32 }}>
          <div style={{ fontSize:40, marginBottom:12 }}>🏢</div>
          <div style={{ fontSize:20, fontWeight:800, color:'#fff' }}>Gestão de Aluguéis</div>
          <div style={{ fontSize:11, color:'#3b4fd8', fontWeight:700, marginTop:4, letterSpacing:1 }}>EJDD · EDEVALDO</div>
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <div>
            <label style={{ fontSize:10, color:'#667799', fontWeight:700, letterSpacing:0.8, textTransform:'uppercase', display:'block', marginBottom:6 }}>Usuário</label>
            <input style={inp} value={usuario} onChange={e=>{ setUsuario(e.target.value); setErro('') }} onKeyDown={e=>e.key==='Enter'&&entrar()} placeholder="seu usuário" autoComplete="username"/>
          </div>
          <div>
            <label style={{ fontSize:10, color:'#667799', fontWeight:700, letterSpacing:0.8, textTransform:'uppercase', display:'block', marginBottom:6 }}>Senha</label>
            <input style={inp} type="password" value={senha} onChange={e=>{ setSenha(e.target.value); setErro('') }} onKeyDown={e=>e.key==='Enter'&&entrar()} placeholder="••••••••" autoComplete="current-password"/>
          </div>
          {erro && <div style={{ color:'#f87171', fontSize:12, fontWeight:600, textAlign:'center' }}>⚠ {erro}</div>}
          <button onClick={entrar} style={{ background:'#3b4fd8', color:'#fff', border:'none', borderRadius:12, padding:'14px', fontSize:14, fontWeight:700, cursor:'pointer', fontFamily:'inherit', marginTop:4 }}>Entrar</button>
        </div>
        <div style={{ marginTop:24, padding:16, background:'#0d0f18', borderRadius:10, fontSize:11, color:'#445566', lineHeight:1.8 }}>
          <div style={{ fontWeight:700, color:'#667799', marginBottom:4 }}>ACESSOS:</div>
          <div>👤 <strong style={{ color:'#7b8ff0' }}>diogo</strong> / ejdd2024</div>
          <div>👤 <strong style={{ color:'#7b8ff0' }}>admin</strong> / alugueis2024</div>
        </div>
      </div>
    </div>
  )
}

function Root() {
  const [user, setUser] = useState(null)
  if (!user) return <Login onLogin={setUser} />
  return (
    <div>
      <div style={{ position:'fixed', top:0, right:0, zIndex:999, padding:'8px 16px', background:'#0d1018', borderLeft:'1px solid #1a1d2e', borderBottom:'1px solid #1a1d2e', borderBottomLeftRadius:12, display:'flex', alignItems:'center', gap:12, fontSize:12, color:'#667799' }}>
        <span>👤 <strong style={{ color:'#e2e4f0' }}>{user.nome}</strong></span>
        <button onClick={()=>setUser(null)} style={{ background:'transparent', border:'1px solid #2a2d40', color:'#f87171', borderRadius:8, padding:'4px 10px', fontSize:11, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>Sair</button>
      </div>
      <App />
    </div>
  )
}

createRoot(document.getElementById('root')).render(
  <StrictMode><Root /></StrictMode>
)
